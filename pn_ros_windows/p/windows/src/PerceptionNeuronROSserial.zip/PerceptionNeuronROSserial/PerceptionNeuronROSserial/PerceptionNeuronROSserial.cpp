// Console application. Registers callback function to send Perception Neuron (PN)
// motion data from Axis Neuron.exe to ROSserial server.

// Tested with Axis Neuron Standard 3.6.32.3944, NeuronDataReaderSDK b12
// and rosserial 0.7.2

#include "stdafx.h"  // Precompiled headers
#include "ros.h"     // ros_lib built with rosserial 0.7.2 - jade-branch
#include <Windows.h>
#include <std_msgs\Float32MultiArray.h>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include "NeuronDataReader.h"
#include <ctime>

// Define global vars, used by main and callback
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
SOCKET_REF sockTCPREF = NULL;
FrameDataReceived _DataReceived;	// Function pointer of type FrameDataReceived
									// which points to function bvhDataReceived
CommandDataReceived _CmdDataReceived;	// Function pointer, type
										// CommandDataReceived, points to
										// cmdDataReceived
BvhDataHeader _bvhHeader;
SocketStatusChanged _SocketStatusChanged;	// Function pointer, type
											// SocketStatusChanged, points to
											// socketStatusChanged

float* _frameDataBuffer = NULL;	// Buffer for incoming frameData values
int frameDataLength = 0;  // Length of motion data stream in type units.
	// MAX_DATA_LENGTH = Max length of float BVH data array in type units. 
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// Rosserial server has restriction on Max Array Length and Max Array Size:
	// Max Array Length: 
	//  was restricted to uint8_t (255) and, since update to rosserial 0.7.2, 
	//  restricted to uint32_t bit by rosserial_server 
	//  Sent Array Length:
	//  354 = 59 (bones) * 6 (3-axis rot. + 3-axis transf.); received from PN
	// Max Array Size:
	//  Default max buffer size increased from 512 to 2047 byte.
	//  Sent data size:
	//  frameDataLength * 4byte (float) + Overhead = 1416 byte + Overhead
	//  Max Array size has been changed in :
	//   in ros_lib->ros->node_handle.h 
	//    int INPUT_SIZE = 2047, // buffer size in byte, standard is 512
	//    int OUTPUT_SIZE = 2047> // buffer size in byte, standard is 512
	//   Linux side : rosserial_server package->Session.h
	// MAX_DATA_LENGTH additionally assures, that AxisNeuron setting WithRef=0
int MAX_DATA_LENGTH = 354;

uint32_t _frameIndex = 0;	// Received PN motion frame ID. 
							// Set as ID of output message
std::string _strframeIndex = std::to_string(_frameIndex);

// Boolean to test for successful registration of callback functions
bool bCallbacks = false;

// Define 3 callback functions on BVH, Cmd and socketStatus Data.
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// Callback for new BVH Data (position data of PN).
// Firstly called in registerNeuronCallbacks by FrameDataReceived, which is
// called by AxisNeuron.exe Afterwords everytimes called by Axis Neuron => 
// gets BVH data als float and saves them in float _frameDataBuffer
// customObject = userDefined Object, sender = Connector reference of TCP/IP
// client as identity, header = Pointer to BVH data header, which contains 
// general information about the BVH data stream, data: BVH data in float array
void bvhDataReceived(void *customObject, SOCKET_REF sender,
	BvhDataHeader *header, float *data) {
	BvhDataHeader *HeaderPtr = header;
	// �nitialize _frameDataBuffer on first call and change frameDataLength if
	// DataCount has changed
	if (HeaderPtr->DataCount != frameDataLength || _frameDataBuffer == NULL) {
		printf("First message received.\n");
		// Check that no reference frame and that displacement is sent. Otherwise
		// data length woulb be too small or big. Set in AxisNeuron->Settings.
		if (HeaderPtr->WithDisp == 0) {
			printf("Set WithDisplacement in AxisNeuron->Settings->Output Format "
				"on true. Terminating node.\n");
			BRCloseSocket(sender);
		}
		if (HeaderPtr->WithReference == 1) {
			printf("Set WithReference in AxisNeuron->Settings->Output Format on "
				"false. Terminating node.\n");
			BRCloseSocket(sender);
		}
		_frameDataBuffer = new float[HeaderPtr->DataCount];
		// Received message is bigger than rosserial_server capacities allow:
		if (HeaderPtr->DataCount > MAX_DATA_LENGTH) {
			printf("Axis Neuron BVH data message is too long. I should be 354 "
				"values long.\n");
		}
		frameDataLength = HeaderPtr->DataCount;  // normally 354
	}
	// Copy received BVH data from data into _frameDataBuffer
	memcpy((char *)_frameDataBuffer, (char *)data,
		(int)HeaderPtr->DataCount * sizeof(float));
	_frameIndex++;
}

// CmdData in b12 not available. Prospectively includes velocity, quaternion,
// acceleration, gyro. Called calculation data in b17.
void cmdDataReceived(void* customObject, SOCKET_REF sockRef, CommandPack* pack,
	void* data) {}
void socketStatusChanged(void* customObject, SOCKET_REF sockRef,
	SocketStatus status, char* message) {
	std::cout << "\nSocket status changed:  message: " << message << "\n";
}

// Registers the function Pointer to the PerceptionNeuronROSserial callback
// functions at the AxisNeuron.exe
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
void registerNeuronCallbacks() {
	bool bBVH = false;
	bool bCmd = false;
	bool bSSt = false;
	void* ptr = NULL;  // placeholder in RegisterCallback funtions

	_DataReceived = FrameDataReceived(bvhDataReceived);
	if (_DataReceived) {
		// Register data-receiving callback handle.
		// Remarks: The handle of FrameDataReceived type points to the function
		// address of the client.
		// CAUTION: BRRegisterFrameDataCallback occasionally crashes the program.
		// Couldnt catch error with BRGetLastErrorMessage
		// TODO: Handle error
		BRRegisterFrameDataCallback(ptr, _DataReceived);
		bBVH = true;
		printf(
			"If PerceptionNeuronRosserial.exe crashes after this message, it "
			"happened during call of void BRRegisterFrameDataCallback() in "
			"PerceptionNeuronROSserial.cpp. No problems with this. Start "
			"PerceptionNeuronROSserial.exe again, it should work after 3 to 4 "
			"trys.\n");
	}
	_CmdDataReceived = CommandDataReceived(cmdDataReceived);
	if (_CmdDataReceived) {
		BRRegisterCommandDataCallback(ptr, _CmdDataReceived);
		bCmd = true;
	}
	_SocketStatusChanged = SocketStatusChanged(socketStatusChanged);
	if (_SocketStatusChanged) {
		BRRegisterSocketStatusCallback(ptr, _SocketStatusChanged);
		bSSt = true;
	}
	bCallbacks = bBVH && bCmd && bSSt;  // bCallbacks is never used again.
}

// High performance counter to precisely reach the desired publishing rate
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// References:
// http://stackoverflow.com/questions/1739259/how-to-use-queryperformancecounter
double PCFreq = 0.0;
__int64 CounterStart = 0;
void StartCounter() {
	LARGE_INTEGER li;
	if (!QueryPerformanceFrequency(&li))
		std::cout << "QueryPerformanceFrequency failed!\n";
	PCFreq = double(li.QuadPart) / 1000.0;
	QueryPerformanceCounter(&li);
	CounterStart = li.QuadPart;
}
double GetCounter() {
	LARGE_INTEGER li;
	QueryPerformanceCounter(&li);
	return double(li.QuadPart - CounterStart) / PCFreq;
}

// Main: creates connection to AxisNeuron server, registers the BVH data
// callback function, which fills frameDataBuffer
// Empties buffer and publishes motion data to ROSserial server.
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
int main(int argc, _TCHAR *argv[]) {

	// Set the IP Addresses to connect between PN and ROS
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// ipAxisNeuron: displayed in AxisNeuron->Settings->General
	// ipROS: displayed in ROS: $ifconfig
	// First, set some default values if no config file found
	std::string ipAxisNeuron = "192.168.1.5";
	std::string ipROS = "192.168.1.3";
	int portAxisNeuron = 7001;
	bool verbose = true;

	// Read config file
	std::ifstream fin("config.txt", std::ios::in);
	std::string line;
	std::istringstream iss;
	if (fin.is_open()) {
		printf("Reading values from config.txt\n");
		while (fin.good()) {
			std::getline(fin, line);
			iss.str(line.substr(line.find("=") + 1));
			if (line.find("ipAxisNeuron") != std::string::npos) {
				printf("IP Axis Neuron %s \n", iss.str().c_str());
				iss >> ipAxisNeuron;

			}
			else if (line.find("portAxisNeuron") != std::string::npos) {
				printf("Port Axis Neuron %s \n", iss.str().c_str());
				iss >> portAxisNeuron;
			}
			else if (line.find("ipROS") != std::string::npos) {
				printf("IP ROS Serial Server %s \n", iss.str().c_str());
				iss >> ipROS;
			}
			iss.clear();
		}
		fin.close();
	}
	else {
		printf("Unable to open config.txt file.. using DEFAULT values. \n");
		printf(
			"ROS Master (Serial Windwos): 192.168.1.3, Axis Neuron 192.168.1.5. "
			"\n");
		printf(
			"The config file should be in same folder as "
			"PerceptionNeuronROSserial.exe \n");
	}
	// Set Pointer to IP address of ROS Master
	char *ros_master = new char[ipROS.length() + 1];
	strcpy(ros_master, ipROS.c_str());
	// Set Pointer to IP address of AxisNeuron
	char *nIP = new char[ipAxisNeuron.length() + 1];
	strcpy(nIP, ipAxisNeuron.c_str());


	// Connect to ROS Master and handle error message
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// ROS master is emulated by rosserial. There's no connection to the real ROS
	// master. No explicit error is thrown for unsuccesful connection,
	// so detection over the stream is necessary
	ros::NodeHandle nh;
	printf("Connecting to ROS Master (ROS Serial Server) at %s \n", ros_master);
	bool connectedToMaster = 0;
	std::string error_msg("Could not connect to server");  // Thrown by initNode()
	std::stringstream buffer;
	std::streambuf * old = std::cerr.rdbuf(buffer.rdbuf()); // reads in the 
									// std::cerr output of nh.initNode(ros_master)
	std::string initNodeOutputStream;
	std::size_t error_occured;
	while (connectedToMaster == 0) {
		nh.initNode(ros_master);  // Initializes the node with parent ros_master ->
								  // ros_master/<node_namespace> ?
		initNodeOutputStream = buffer.str();  // Copies the output from initNode()
		std::cout << initNodeOutputStream;
		error_occured = initNodeOutputStream.find(error_msg);	// Searches for 
												// error msg in server connection
		if (error_occured != std::string::npos) {	// Found error_msg in
						// initNodeOutputStream at position error_occured
			printf("Please assure that ROS Master is connected under the IP Address:"
				" %s \n", ros_master);
			Sleep(2000);
			printf("\nRetrying connection.\n");
			initNodeOutputStream.clear();
			buffer.str(std::string());  // Clear buffer stringstream
		}
		else {
			printf("Connected successfully to ROS Master\n");
			connectedToMaster = 1;
		}
	}


	// Connect to AxisNeuron
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// Frame rate of PerceptionNeuronROSserial output:
	// PN sends at 60 Hz for 19-32 connected IMUs; 120Hz for 18 or less.
	// 60Hz are maintained at 0.00ms std deviation, 120Hz show deviations of 10ms
	double framesPerSecPercNeuron = 60;
	// Neuron Connection
	void* neuronptr = NULL;  // pointer to socket

	// BRCloseSocket would disconnect old socket, but neuronptr set to NULL
	if (BRGetSocketStatus(neuronptr) == SocketStatus::CS_Running) {
		BRCloseSocket(neuronptr);
		printf("Closed old running socket. \n");
	}
	// Connects to server of AxisNeuron and returns handle to its identity
	// otherwise NULL is returned
	neuronptr = BRConnectTo(nIP, portAxisNeuron);
	if (neuronptr == NULL) {
		printf("Axis Neuron Connection refused! \n ");
		return 0;  // Terminate program.
	}
	else {
		printf("Connected to Axis Neuron at %s \n", nIP);
	}


	// Register the internal callbacks at AxisNeuron, s.t. it sends BVH motion data
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// CAUTION: This method can produce undeclared error messages. These are caused
	// by the call of: BDR_API void BRRegisterFrameDataCallback()
	registerNeuronCallbacks();


	// Prepare the message for the ros publisher
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// Rosserial server requires that all message content is allocated seperately
	// and only a pointer and its data length is passed.

	// Float32MultiArray, because Perception Neuron data precision is max. float32
	std_msgs::Float32MultiArray frameDataMsg;

	// Wait until frameDataLength is set by bvhDataReceived to instantiate message
	// of the desired size
	while (frameDataLength == 0) {
		printf("Wait until first data is received from Axis Neuron.\n");
		Sleep(500);
	}

	frameDataMsg.layout.dim_length = 1;
	// Without seperate initialization of MultiArrayDimension rosserial causes an
	// "System.AccessViolationException" error.
	// Float32MultiArray gives the possibility of sending multi-dimensional arrays.
	// Nevertheless, our message is one-dimensional -> msgLayout[1]
	std_msgs::MultiArrayDimension msgLayout[1];
	msgLayout->label = _strframeIndex.c_str();  // PN frame id used as message
												// label, not only to identify lost
												// messages
	msgLayout->size = frameDataLength;  // size of data array in type units (float)
	msgLayout->stride = frameDataLength;	// stride of data in type units (float)
	frameDataMsg.layout.dim = msgLayout;
	frameDataMsg.layout.data_offset = 0;  // padding elements at front of data

	// 354 = frameDataLength
	float posDataArrayMemory[354];  // allocates static memory, that the message
									// data pointer refers to
	for (int i = 0; i < frameDataLength; i++) {
		posDataArrayMemory[i] = _frameDataBuffer[i];
	}
	// Rosserial copies the frameDataMsg.data vector into an array of size 
	// data_length. A zero value causes that rosserial does not read in any data.
	frameDataMsg.data_length = frameDataLength;
	frameDataMsg.data = posDataArrayMemory;

	printf("Prepared data msgs\n");


	// Prepare the ROS Publisher to broadcast PN data on /perception_neuron/data
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	// Standard way of initializing the publisher does not work, as this is a
	// lightweight ROS library for windows.
	ros::Publisher pub("/perception_neuron/data", &frameDataMsg);
	printf("Created ros publisher\n");

	nh.advertise(pub);
	printf("\n \nAdvertising Axis Neuron Data to ROS Serial Server\n");
	nh.spinOnce();

	// Wait a bit, till first data arrived from Axis Neuron.
	Sleep(1000);

	// Variables for avg frequency, timer, logfile and msgID
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	clock_t begin = clock();
	int sentFrames = 0;
	double measuredAvgFramerate = 0;
	int avgTimeFrameWindow = 60;  // number of frames before building the avg

	// High-resolution timer:
	StartCounter();
	double cycleTime = 1000 * 1 / framesPerSecPercNeuron;
	double elapsedTime = 0;
	double winSleepVar = 1;  // std deviation of Windows::Sleep() in ms

	// Uncomment for CSV logfile output:
	// std::ofstream logFile;
	// std::string logFileName = "percNeuronROSserialLog.csv";
	// logFile.open(logFileName);
	// logFile << "PerceptionNeuronROSserial console output log\n";
	// logFile << "msgID; motionFrameID; publishInterval*10^5\n";

	// Message Index:
	int msgID = 0;
	std::string strMsgID;

	// nh.ok() not provided in rosserial ros library -> while(1)
	while (1) {
		// Set output message label:
		// ^^^^^^^^^^^^^^^^^^^^^^^^^
		// Set msgID as output message label (for lost msg control)
		// strMsgID = std::to_string(msgID);
		// frameDataMsg.layout.dim->label = strMsgID.c_str();
		// Set PN frame ID as output message label
		_strframeIndex = std::to_string(_frameIndex);
		frameDataMsg.layout.dim->label = _strframeIndex.c_str();
		if (verbose) {
			printf(" | Msg ID %d | PN motion frame ID %d | ", msgID, _frameIndex);
			// logFile << frameDataMsg.layout.dim->label << ";" << _frameIndex << ";";
		}
		msgID++;

		// Copy from callback received motion data into message and publish
		// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		if (_frameDataBuffer != NULL) {
			if (_frameDataBuffer[frameDataLength - 1]) {
				for (int i = 0; i < frameDataLength; i++) {
					frameDataMsg.data[i] = _frameDataBuffer[i];
				}
				pub.publish(&frameDataMsg);
			}
		}
		else {
			printf("No values in PN motion data buffer \n");
			Sleep(1000);
		}
		nh.spinOnce();

		// Avg Frame Rate Measurement
		// ^^^^^^^^^^^^^^^^^^^^^^^^^^
		sentFrames++;
		if (sentFrames > avgTimeFrameWindow) {
			measuredAvgFramerate =
				(sentFrames / (double(clock() - begin) / CLOCKS_PER_SEC));
			sentFrames = 0;
			begin = clock();
		}
		printf("avg frames p sec = %f", measuredAvgFramerate);

		// Rate adjustion with High Resolution Counter:
		// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		elapsedTime = GetCounter();
		// Vague time-out with Windows::Sleep()
		if ((cycleTime - elapsedTime - winSleepVar) > 0) {
			Sleep(cycleTime - elapsedTime - winSleepVar);
		}
		// Precise spinning to hit cycleTime
		int i = 0;
		while (GetCounter() < cycleTime) {
			i++;
		}
		// logFile << GetCounter() << "\n";
		printf("\ncycle time: %f", GetCounter());
		StartCounter();
	}
	BRCloseSocket(neuronptr);
	printf("All done!\n");
	return 0;
}